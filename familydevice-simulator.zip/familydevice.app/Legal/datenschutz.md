# Datenschutz 

_DSGVO · DATENSCHUTZ DURCH TECHNIKGESTALTUNG · ART. 25_

familydevice ist so gebaut, dass wir möglichst nichts über deine Familie wissen. Die App hat keinen Server bei uns – deine Regeln, Anfragen und Freigaben bleiben auf euren iPhones.

## Verantwortlicher 

Verantwortlich im Sinne der DSGVO ist die ANTICIPATER GmbH, Alter Schlachthof 39, 76131 Karlsruhe, vertreten durch Thorsten Reiser. Kontakt: hallo@anticipater.com · +49 (0) 721 619 025 28.

## Die App 

**Die App verbindet sich mit keinem Server von uns, und wir erhalten keine Daten über deine Familie.** Kein Konto bei uns, keine Analyse-Tools, keine Werbe- oder Tracking-SDKs. Welche anderen Dienste beteiligt sind, steht unten unter „Empfänger im Überblick“.

**Auf den Geräten** speichert die App: Namen, die du für dich und dein Kind vergibst, eure Zeitpläne, App-Gruppen, Freigabe-Anfragen und Entscheidungen der letzten 30 Tage sowie die kryptografischen Schlüssel der Kopplung. Welche Apps in einer Gruppe gesperrt werden, kennt nur das Kinder-iPhone selbst – Apple gibt diese Auswahl nicht an andere Geräte oder an uns weiter.

**Zwischen den Geräten** werden diese Daten Ende-zu-Ende verschlüsselt übertragen: in der Nähe direkt (lokales Netzwerk/Bluetooth), sonst über die **iCloud** der beteiligten Apple-IDs. Apple speichert dabei nur verschlüsselte Nachrichten, die es nicht lesen kann, und stellt Mitteilungen über den Apple-Push-Dienst zu. Damit eine Mitteilung sichtbar ankommt, legt das sendende iPhone zusätzlich einen leeren „Weckruf“ in der öffentlichen iCloud-Datenbank der App ab: nur eine zufällige, aus der Kopplung abgeleitete Kennung des Empfängers, ohne Inhalt; jeder neue Weckruf ersetzt den vorigen. Verantwortlich für iCloud ist Apple; es gelten die Datenschutzbestimmungen von Apple.

**Bildschirmzeit:** Die App nutzt Apples Bildschirmzeit-Schnittstelle (Family Controls). Die Auswertung unter „Nutzung & Bewegung“ (Bildschirmzeit, Entsperrungen, meistgenutzte Apps) erstellt eine abgeschottete Apple-Erweiterung direkt auf dem iPhone; diese Daten verlassen das Gerät nicht und sind weder für die übrige App noch für uns lesbar.

**Bewegung:** Wenn du es in den iPhone-Einstellungen erlaubst (Bewegung & Fitness), liest die App Schritte, Strecke und Bewegungsminuten (gehen, laufen, Rad, Auto) des aktuellen Tages aus den Bewegungssensoren. Auf dem Kinder-iPhone werden Tageszusammenfassungen – nur Zahlen, keine Positionen – Ende-zu-Ende verschlüsselt an die gekoppelten Eltern-iPhones gesendet, die sie 30 Tage aufbewahren. Rechtsgrundlage ist deine Einwilligung (Art. 6 Abs. 1 lit. a DSGVO), die du in den iPhone-Einstellungen jederzeit widerrufen kannst.

**Orte:** Eltern können auf ihrem iPhone Orte wie „Zuhause“ oder „Schule“ anlegen – über eine Adresssuche (Apple Karten) oder den eigenen Standort – mit einem Umkreis. Erlaubst du auf dem Kinder-iPhone den Standortzugriff „Immer“, überwacht iOS diese Umkreise auf dem Gerät und die App meldet nur das Ankommen und Verlassen (Ort, Zeitpunkt) Ende-zu-Ende verschlüsselt an die gekoppelten Eltern-iPhones; eine Position wird dabei nicht übertragen. Wenn-Dann-Regeln können darauf reagieren. Rechtsgrundlage ist die Einwilligung der sorgeberechtigten Eltern (Art. 6 Abs. 1 lit. a DSGVO); das Löschen eines Ortes in der App oder der Entzug des Standortzugriffs in den iPhone-Einstellungen beendet die Verarbeitung.

**Bewegungsprofil (optional, standardmäßig aus):** Schalten Eltern es für ein Kind ein, zeichnet das Kinder-iPhone wesentliche Ortsänderungen und Aufenthalte (Apple-Ortungsdienste, nicht minutengenau) auf, behält sie 30 Tage und sendet sie Ende-zu-Ende verschlüsselt an die gekoppelten Eltern-iPhones, die den Weg des Tages auf einer Karte zeigen. Das Kind sieht in seiner App, dass das Bewegungsprofil eingeschaltet ist. Ausschalten löscht den Verlauf auf beiden iPhones. Rechtsgrundlage ist die Einwilligung der sorgeberechtigten Eltern (Art. 6 Abs. 1 lit. a DSGVO), jederzeit in der App widerrufbar. Wir erhalten davon nichts.

**Netzwerk:** Ist die Netzwerk-Messung eingeschaltet (auf Kinder-iPhones automatisch mit der Bildschirmzeit-Freigabe), zählt ein Inhaltsfilter direkt auf dem iPhone, welche Domains und Apps wie viele Verbindungen und Daten nutzen. Inhalte von Verbindungen werden nicht gelesen oder gespeichert. Außerdem merkt sich der Filter, wann das Kinder-iPhone entsperrt und wieder gesperrt wurde (nur Uhrzeiten, 30 Tage auf dem Gerät), und sendet die Zeiten von heute und gestern Ende-zu-Ende verschlüsselt an die gekoppelten Eltern-iPhones; das Kind sieht das unter „Was deine Eltern sehen“. Die Zählung liegt nur auf dem Gerät; Kinder-iPhones senden eine Tageszusammenfassung (Gesamtmenge, meistgenutzte Domains und Apps) Ende-zu-Ende verschlüsselt an die gekoppelten Eltern-iPhones. Wir erhalten davon nichts.

**Schutzliste und Werbe-Blocker:** Das iPhone gleicht aufgerufene Domains mit mitgelieferten Listen ab und blockiert Treffer – auf Kinder-iPhones im Netzwerkfilter. Die Schutzliste gegen Schadsoftware-, Phishing- und Betrugs-Domains (HaGeZi Threat Intelligence Feeds) ist eingeschaltet, bis die Eltern sie abschalten; der Werbe- und Tracker-Blocker (Steven Black Hosts) ist optional. Der Abgleich findet ausschließlich auf dem Gerät statt; die Listen kommen mit jeder App-Version und werden ab iOS 26 zusätzlich über den App Store von Apple aktualisiert (Apple-gehostete Zusatzdaten der App, für alle Nutzer gleich, ohne Angaben über dich oder dein Kind). Bei einem Treffer zeigt das iPhone eine Mitteilung mit der blockierten Domain und Safari eine Sperrseite; deren Link „Warum blockiert?“ öffnet familydevice.com/blockiert ohne Angaben zur Domain oder zu dir – nur wenn du ihn antippst. Gezählt wird nur, wie oft und welche Domain blockiert wurde; Kinder-iPhones senden diese Zählung mit der Tageszusammenfassung Ende-zu-Ende verschlüsselt an die Eltern-iPhones, damit Eltern sehen, wenn eine App oder Website Verbindungen zu Schadsoftware-Domains aufbaut.

**Updates** verteilt Apple über TestFlight bzw. den App Store. Welche Version auf den anderen gekoppelten iPhones läuft, erfahren die Geräte untereinander über die verschlüsselte Verbindung – die App fragt dafür bei keinem Server nach.

**Kauf und Abo** wickelt Apple ab. Wir erhalten von Apple nur anonymisierte Verkaufsberichte, keine Zahlungsdaten und keine Namen.

**Fehlerberichte:** Wenn du in den iPhone-Einstellungen das Teilen von Analysedaten mit App-Entwicklern erlaubt hast, stellt Apple uns anonyme Absturzberichte bereit. Das kannst du dort jederzeit abschalten.

## Die Website familydevice.com 

Beim Aufruf der Website verarbeitet unser Hosting-Anbieter Vercel Inc. technisch notwendige Server-Logs (IP-Adresse, Zeitpunkt, aufgerufene Seite, Browser) zur Auslieferung und Absicherung der Seite. Grundlage ist Art. 6 Abs. 1 lit. f DSGVO; die Übermittlung in die USA stützt sich auf das EU-US Data Privacy Framework bzw. Standardvertragsklauseln. Die Website setzt **keine Cookies**, hat keine Anmeldung und bindet keine Analyse-Tools ein. Mit Vercel besteht ein Vertrag zur Auftragsverarbeitung (Art. 28 DSGVO).

Die Website schlägt dir eine andere Sprachfassung vor, wenn dein Browser eine unserer Sprachen bevorzugt. Dafür liest die Seite die Spracheinstellung deines Browsers, die er ohnehin jeder Website mitteilt, nur in deinem Browser aus; gespeichert oder an uns übertragen wird dabei nichts.

Wenn du uns per E-Mail schreibst – etwa für den Beta-Zugang –, verarbeiten wir deine Nachricht und E-Mail-Adresse zur Beantwortung (Art. 6 Abs. 1 lit. b bzw. f DSGVO) und löschen sie, wenn sie nicht mehr gebraucht werden.

## Kinder und Jugendliche 

familydevice ist für Familien gemacht, in denen Eltern die iPhone-Nutzung ihrer Kinder begleiten. Die Funktionen, die etwas über das Kind mitteilen – Orte, Bewegungsprofil, Bewegung, Netzwerk –, sind entweder standardmäßig aus oder brauchen eine Erlaubnis in den iPhone-Einstellungen des Kindes. **Nichts davon ist heimlich:** Die App auf dem Kinder-iPhone zeigt unter „Was deine Eltern sehen“, was gerade an die Eltern geht, solange es eingeschaltet ist.

Die Einwilligung der Eltern ersetzt nicht das Gespräch mit dem Kind. Je älter das Kind ist, desto mehr zählt seine eigene Meinung; ab 16 Jahren sollte es Funktionen wie Orte oder das Bewegungsprofil selbst mittragen. Wir haben für diese Funktionen eine Datenschutz-Folgenabschätzung (Art. 35 DSGVO) durchgeführt.

## Empfänger im Überblick 

**Apple:** iCloud (verschlüsselte Nachrichten zwischen euren iPhones), Push-Dienst, Apple Karten (Adresssuche für Orte), TestFlight/App Store (Updates, aktuelle Schutzlisten, Kauf, Abo, freiwillige Absturzberichte)
**Vercel:** Nur die Website familydevice.com: technisch notwendige Server-Logs
**Wir:** Nur E-Mails, die du uns schreibst – aus der App erhalten wir nichts

## Was wir bewusst nicht tun 

- Kein Google Analytics, kein Plausible, kein Matomo, kein Facebook-Pixel – weder in der App noch auf der Website.
- Kein Werbe-Tracking, keine Drittanbieter-Cookies, keine Werbe-SDKs.
- Keine Profile über das Nutzungs-, Surf- oder Bewegungsverhalten deiner Kinder bei uns – alles bleibt in eurer Familie.
- Kein Verkauf und keine Weitergabe von Daten.

## Löschen 

Daten der App liegen auf euren Geräten und in eurer iCloud. „Entkoppeln“ in der App löscht Schlüssel, Regeln und Verlauf auf dem Gerät und die zugehörigen iCloud-Bereiche; das Löschen der App entfernt den Rest vom Gerät.

## Deine Rechte 

Du hast das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung, Datenübertragbarkeit und Widerspruch. Schreib uns an hallo@anticipater.com – wir antworten innerhalb von 30 Tagen. Du kannst dich außerdem bei der für uns zuständigen Aufsichtsbehörde beschweren: Landesbeauftragter für den Datenschutz und die Informationsfreiheit Baden-Württemberg.

---

_STAND · OKTOBER 2026_
