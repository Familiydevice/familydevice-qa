# Allgemeine Geschäftsbedingungen 

_FAMILYDEVICE · STAND OKTOBER 2026_

Diese Bedingungen regeln die Nutzung der familydevice-App für iPhone. Kauf und Abo laufen über den App Store von Apple.

## § 1 Geltungsbereich 

Diese Allgemeinen Geschäftsbedingungen (AGB) gelten für die Nutzung der iOS-App „familydevice“ der ANTICIPATER GmbH, Alter Schlachthof 39, 76131 Karlsruhe (nachfolgend „Anbieter“). Ergänzend gilt die Lizenzvereinbarung für Endnutzer:innen von Apple (Standard-EULA) in ihrer jeweils gültigen Fassung. Bei Widersprüchen gehen die Regelungen von Apple zu Kauf, Abrechnung und Kündigung vor.

## § 2 Leistung 

familydevice ist eine App zur Begleitung der Bildschirmzeit von Kindern. Sie nutzt die Bildschirmzeit-Schnittstelle von Apple (Family Controls), um auf dem iPhone eines Kindes Apps und Websites nach Zeitplänen zu sperren, Freigaben anzufragen und zu erteilen. Eltern- und Kinder-iPhone werden direkt miteinander gekoppelt; Nachrichten zwischen den Geräten sind Ende-zu-Ende verschlüsselt und werden in der Nähe direkt, sonst über die iCloud der Nutzer:innen übertragen. Der Anbieter betreibt dafür keinen eigenen Server.

Voraussetzungen sind ein iPhone mit iOS 17 oder neuer, für das Kinder-iPhone ein Kinder-Account in der Apple-Familienfreigabe der Eltern sowie aktivierte iCloud für die Übertragung über größere Entfernungen.

## § 3 Vertragsschluss, Preise und Abo 

Die App ist im App Store kostenlos. Solange kein Kinder-iPhone gekoppelt ist, sind Einrichtung und Simulation kostenlos. Sobald ein Kinder-iPhone gekoppelt wird, setzt die Nutzung der Eltern-Funktionen ein **Abonnement** voraus: **10 € pro Monat für das erste Kind** und **1 € pro Monat für jedes weitere Kind**. Für mehr als sechs Kinder fällt kein weiterer Aufpreis an. Koppelst du ein weiteres Kind, wird das Abo über den App Store auf die neue Anzahl umgestellt. Alle Preise verstehen sich inklusive gesetzlicher Umsatzsteuer.

Kauf und Abo werden über die Apple-ID abgeschlossen und von Apple abgerechnet. Das Abo verlängert sich automatisch um jeweils einen Monat, sofern es nicht spätestens 24 Stunden vor Ablauf des laufenden Zeitraums in den Einstellungen der Apple-ID gekündigt wird. Erstattungen und Widerruf richten sich nach den Bedingungen von Apple.

Endet das Abo, bleiben bestehende Sperren auf Kinder-iPhones aus Sicherheitsgründen wirksam, bis sie von den Eltern geändert oder die Geräte entkoppelt werden.

## § 4 Pflichten der Nutzer:innen 

Du bestätigst, volljährig und für die eingerichteten Kinder-iPhones sorgeberechtigt bzw. berechtigt zu sein. Du schützt deine Eltern-PIN und den Bildschirmzeit-Code vor dem Zugriff deines Kindes. familydevice darf nicht genutzt werden, um Geräte anderer Erwachsener ohne deren Wissen zu kontrollieren.

## § 5 Grenzen der Technik 

familydevice schließt die bekannten Umgehungswege, die Apples Bildschirmzeit offenlässt. Eine vollständige Unumgehbarkeit kann niemand garantieren.

Insbesondere kann ein iPhone von Personen, die Gerätecode und Apple-ID kennen, gelöscht werden; familydevice erkennt das und meldet ausbleibende Rückmeldungen, verhindert es aber nicht. Die Funktion hängt von Diensten Apples (Bildschirmzeit, iCloud, Mitteilungen) ab, auf deren Verfügbarkeit der Anbieter keinen Einfluss hat.

## § 6 Haftung 

Der Anbieter haftet uneingeschränkt für Vorsatz und grobe Fahrlässigkeit sowie für Schäden aus der Verletzung des Lebens, des Körpers oder der Gesundheit. Bei leicht fahrlässiger Verletzung wesentlicher Vertragspflichten ist die Haftung auf den vorhersehbaren, vertragstypischen Schaden begrenzt. Im Übrigen ist die Haftung ausgeschlossen. Die Haftung nach dem Produkthaftungsgesetz bleibt unberührt.

## § 7 Änderungen 

Der Anbieter kann die App weiterentwickeln und diese AGB mit Wirkung für die Zukunft ändern, soweit dies für dich zumutbar ist. Über wesentliche Änderungen informieren wir in der App oder auf familydevice.com. Preisänderungen des Abos werden über Apple angekündigt und bedürfen, soweit von Apple vorgesehen, deiner Zustimmung.

## § 8 Anwendbares Recht und Gerichtsstand 

Es gilt das Recht der Bundesrepublik Deutschland unter Ausschluss des UN-Kaufrechts; zwingende Verbraucherschutzvorschriften deines gewöhnlichen Aufenthaltsstaats bleiben unberührt. Gerichtsstand ist Karlsruhe, sofern du Kaufmann, juristische Person des öffentlichen Rechts oder öffentlich-rechtliches Sondervermögen bist. Wir sind zur Teilnahme an Streitbeilegungsverfahren vor einer Verbraucherschlichtungsstelle weder verpflichtet noch bereit.

---

**Anbieter:** ANTICIPATER GmbH
**Anschrift:** Alter Schlachthof 39 · 76131 Karlsruhe
**E-Mail:** hallo@anticipater.com
**Telefon:** +49 (0) 721 619 025 28
**Stand:** Oktober 2026
