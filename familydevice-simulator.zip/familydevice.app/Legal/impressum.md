# Impressum 

_ANGABEN GEMÄSS § 5 DDG · STAND OKTOBER 2026_

familydevice ist ein Produkt der ANTICIPATER GmbH, Karlsruhe.

**Betreiber:** ANTICIPATER GmbH
**Anschrift:** Alter Schlachthof 39 · 76131 Karlsruhe · DE
**Telefon:** +49 (0) 721 619 025 28
**E-Mail:** hallo@anticipater.com
**Handelsregister:** HRB 752025 · Amtsgericht Mannheim
**Umsatzsteuer-ID:** DE370089490

## Verantwortlich für den Inhalt nach § 18 Abs. 2 MStV 

Thorsten Reiser · Alter Schlachthof 39 · 76131 Karlsruhe.

## Verbraucherstreitbeilegung 

Wir sind nicht bereit oder verpflichtet, an Streitbeilegungsverfahren vor einer Verbraucherschlichtungsstelle teilzunehmen.

## Haftung für Inhalte 

Als Diensteanbieter sind wir gemäß § 7 Abs. 1 DDG für eigene Inhalte auf diesen Seiten nach den allgemeinen Gesetzen verantwortlich. Nach §§ 8 bis 10 DDG sind wir als Diensteanbieter nicht verpflichtet, übermittelte oder gespeicherte fremde Informationen zu überwachen oder nach Umständen zu forschen, die auf eine rechtswidrige Tätigkeit hinweisen. Verpflichtungen zur Entfernung oder Sperrung der Nutzung von Informationen nach den allgemeinen Gesetzen bleiben hiervon unberührt. Eine Haftung ist erst ab Kenntnis einer konkreten Rechtsverletzung möglich. Bei Bekanntwerden entsprechender Rechtsverletzungen entfernen wir Inhalte umgehend.

## Haftung für Links 

Unser Angebot enthält Links zu externen Websites Dritter, auf deren Inhalte wir keinen Einfluss haben. Für diese fremden Inhalte können wir keine Gewähr übernehmen. Für die Inhalte der verlinkten Seiten ist stets der jeweilige Anbieter verantwortlich. Die Seiten wurden zum Zeitpunkt der Verlinkung auf mögliche Rechtsverstöße überprüft; rechtswidrige Inhalte waren nicht erkennbar. Eine permanente inhaltliche Kontrolle ist ohne konkrete Anhaltspunkte nicht zumutbar. Bei Bekanntwerden von Rechtsverletzungen entfernen wir derartige Links umgehend.

## Urheberrecht 

Die durch die Seitenbetreiber erstellten Inhalte und Werke auf diesen Seiten unterliegen dem deutschen Urheberrecht. Vervielfältigung, Bearbeitung, Verbreitung und jede Art der Verwertung außerhalb der Grenzen des Urheberrechts bedürfen der schriftlichen Zustimmung. Downloads und Kopien dieser Seite sind nur für den privaten, nicht kommerziellen Gebrauch gestattet. Inhalte Dritter werden als solche gekennzeichnet; bitte weise uns auf etwaige Urheberrechtsverletzungen hin – wir entfernen sie umgehend.

familydevice ist eine Produktmarke der ANTICIPATER GmbH. Apple, iPhone, iOS, Apple MDM und Apple Business Manager sind Marken der Apple Inc. familydevice steht in keiner geschäftlichen Verbindung zu Apple Inc.
