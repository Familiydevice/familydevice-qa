# Impressum 

_ANGABEN GEMÄSS § 5 DDG · STAND OKTOBER 2026_

familydevice ist ein Produkt der ANTICIPATER GmbH, Karlsruhe.

**Anbieter:** ANTICIPATER GmbH
**Anschrift:** Alter Schlachthof 39 · 76131 Karlsruhe · Deutschland
**Vertreten durch:** Thorsten Reiser (Geschäftsführer)
**Telefon:** +49 (0) 721 619 025 28
**E-Mail:** hallo@anticipater.com
**Registereintrag:** Handelsregister B, Amtsgericht Mannheim, HRB 752025
**Umsatzsteuer-ID:** DE370089490 (§ 27a UStG)

## Verantwortlich für den Inhalt nach § 18 Abs. 2 MStV 

Thorsten Reiser · Alter Schlachthof 39 · 76131 Karlsruhe.

## Verbraucherstreitbeilegung 

Wir sind nicht bereit und nicht verpflichtet, an Streitbeilegungsverfahren vor einer Verbraucherschlichtungsstelle teilzunehmen (§ 36 VSBG).

## Haftung 

Für eigene Inhalte haften wir nach den allgemeinen Gesetzen. Für die Inhalte verlinkter Websites Dritter ist allein deren Anbieter verantwortlich. Erfahren wir von einer Rechtsverletzung auf unseren Seiten oder auf einer verlinkten Seite, entfernen wir den Inhalt oder den Link umgehend. Hinweise bitte an hallo@anticipater.com.

## Urheberrecht 

Texte, Bilder und Gestaltung dieser Website sind urheberrechtlich geschützt. Eine Verwendung außerhalb der gesetzlichen Grenzen bedarf unserer schriftlichen Zustimmung. Inhalte Dritter sind als solche gekennzeichnet.

familydevice ist eine Produktmarke der ANTICIPATER GmbH. Apple, iPhone, iOS, Apple MDM und Apple Business Manager sind Marken der Apple Inc. familydevice steht in keiner geschäftlichen Verbindung zu Apple Inc.
